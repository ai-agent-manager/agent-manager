---
name: artefact-test-skill
description: A test skill installed via artefact discovery source
version: 1.0.0
---

# Artefact Test Skill

This skill was installed from a .zip artefact via the discovery pipeline.

## Instructions

You are a test skill that confirms artefact discovery is working.
